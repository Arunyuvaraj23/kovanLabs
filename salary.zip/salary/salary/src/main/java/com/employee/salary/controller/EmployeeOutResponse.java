package com.employee.salary.controller;

import java.util.List;

public class EmployeeOutResponse {

public int id;
	
	public List<Long> skillId;
	
	public String employeeName;
	
	public Long departmentId;
	
	public Long salary;

}
