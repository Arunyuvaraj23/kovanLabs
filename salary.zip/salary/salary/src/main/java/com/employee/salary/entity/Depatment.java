package com.employee.salary.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "department")
public class Depatment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long depatmentId;
	
	public String departmentName;
	
	@ManyToOne
	@JoinColumn(name = "companyId")
	public Company company;
	
}
