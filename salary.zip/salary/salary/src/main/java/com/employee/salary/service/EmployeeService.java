package com.employee.salary.service;

import com.employee.salary.controller.EmployeeOutResponse;
import com.employee.salary.dto.EmployeeInRequest;

public interface EmployeeService {

	EmployeeOutResponse createEmployee(EmployeeInRequest employeeInRequest);

}
