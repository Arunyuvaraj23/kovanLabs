package com.employee.salary.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	public Long id;
	
	public String employeeName;
	
	public String designation;
	
	@ManyToOne
	@JoinColumn(name = "departmentId")
	public Depatment depatment;
	
	public Long salary;
	
	@ManyToOne
	@JoinColumn(name = "skillId")
	public Skill skill;

}
