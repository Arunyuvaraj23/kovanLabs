package com.employee.salary.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "company")
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Long companyId;
	
	public String companyName;
	
	@OneToMany(mappedBy = "company")
	public List<Depatment> depatments;
	
	@OneToMany(mappedBy = "company")
	public List<Employee> employees;
	
	
}
