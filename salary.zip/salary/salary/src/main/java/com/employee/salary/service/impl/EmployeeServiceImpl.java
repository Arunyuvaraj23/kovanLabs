package com.employee.salary.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.salary.controller.EmployeeOutResponse;
import com.employee.salary.dto.EmployeeInRequest;
import com.employee.salary.entity.Employee;
import com.employee.salary.repo.EmployeeRepository;
import com.employee.salary.repo.SkillRepository;
import com.employee.salary.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	
	@Autowired
	private EmployeeRepository empRepo;
	
	@Autowired
	private SkillRepository skillRepo;

	@Override
	public EmployeeOutResponse createEmployee(EmployeeInRequest employeeInRequest) {
		
		Employee employee = new Employee();
		
		
		return null;
	}

}
