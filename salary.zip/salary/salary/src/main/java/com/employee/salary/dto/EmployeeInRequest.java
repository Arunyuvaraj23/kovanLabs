package com.employee.salary.dto;

import java.util.List;

public class EmployeeInRequest {
	
	public int id;
	
	public List<Long> skillId;
	
	public String employeeName;
	
	public Long departmentId;
	
	public Long salary;

}
