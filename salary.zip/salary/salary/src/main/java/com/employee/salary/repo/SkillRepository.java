package com.employee.salary.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.employee.salary.entity.Skill;

public interface SkillRepository extends JpaRepository<Skill, Long>{

}
