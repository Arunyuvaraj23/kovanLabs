package com.inter.code;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ProcessingTime {
	
	public static void main(String[] args) {
		
		 File file = new File(ProcessingTime.class.getResource("processingtime.txt").getPath());
		 List<Integer> processingTime = new ArrayList<>();
		 
	        try (BufferedReader br = new BufferedReader(new FileReader(file)))
	        {
	            String line;
	            while ((line = br.readLine()) != null) {
	            	if(line.contains("ProcessingTimeTook")){
	            		String[] processingArray = line.split("\\s");
	            		for(String process:processingArray) {
	            			try {
	            				processingTime.add(Integer.parseInt(process));
	            			}catch(Exception e) {
	            				
	            			}
	            		}
	            		
	            	}
	            	
	            }
	            System.out.println("Average Processing Time: "+calculateAvgTime(processingTime));
	            System.out.println("Maximum Processing Time: "+findMax(processingTime));
	        } catch (IOException e) {
	            e.printStackTrace();
	        }	
	}
	
	public static double calculateAvgTime(List<Integer> avg) {
		return avg.stream().mapToInt(av->av).average().orElse(0);
	}
	
	public static int findMax(List<Integer> max) {
		return Collections.max(max);
	}

}
